const fs = require('fs');
const requiredFiles = ['server.js', 'package.json', 'public/index.html', 'public/manifest.json'];
console.log("🛡️ RUNNING SYSTEM DIAGNOSTICS...");
let healthy = true;
requiredFiles.forEach(file => {
    if (!fs.existsSync(file)) {
        console.error(`❌ CRITICAL ERROR: Missing ${file}`);
        healthy = false;
    } else {
        console.log(`✅ CHECKED: ${file}`);
    }
});
if (!healthy) {
    console.error("⚠️ SYSTEM CORRUPTED. REPAIR REQUIRED.");
    process.exit(1);
} else {
    console.log("🟢 ALL SYSTEMS GO. HOSTING ANYWHERE ALLOWED.");
}
