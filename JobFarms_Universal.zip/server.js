require("./integrity.js");
const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// 🔐 SUPER ADMIN CREDENTIALS
const ADMIN_USER = "mrsalmanraz@gmail.com";
const ADMIN_PASS = "admin123";

// 🟢 LOGIN API
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    if (email === ADMIN_USER && password === ADMIN_PASS) {
        res.json({ success: true, token: "GOD_MODE_ACCESS_GRANTED" });
    } else {
        res.status(401).json({ success: false, msg: "INVALID CREDENTIALS" });
    }
});

// 🟢 DASHBOARD DATA
app.get('/api/data', (req, res) => {
    res.json({
        revenue: "$1,500,042,900.00",
        workers: [
            { name: "Vikram Rathore", status: "ON_DUTY" },
            { name: "Anjali Sharma", status: "AVAILABLE" }
        ],
        system: "GOD-MODE: LIVE"
    });
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`\n🚀 SERVER READY on PORT ${PORT}`);
});

module.exports = app;
